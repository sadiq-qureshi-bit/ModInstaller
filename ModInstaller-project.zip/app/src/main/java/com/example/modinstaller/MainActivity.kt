package com.example.modinstaller

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private val defaultDir = "/storage/emulated/0/Android_unprotected/data"
    private val reqPick = 100
    private val reqPerm = 101

    private lateinit var etDir: EditText
    private lateinit var tvLog: TextView

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val backupDir by lazy { File(getExternalFilesDir(null), "backup") }
    private val installedList by lazy { File(getExternalFilesDir(null), "installed.txt") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        root.addView(TextView(this).apply {
            text = "Mod install folder:"
        }, lp)

        etDir = EditText(this).apply {
            setText(prefs.getString("dir", defaultDir))
        }
        root.addView(etDir, lp)

        root.addView(Button(this).apply {
            text = "Mod select karke install karo"
            setOnClickListener {
                if (!hasAccess()) askAccess() else {
                    prefs.edit().putString("dir", etDir.text.toString().trim()).apply()
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(i, reqPick)
                }
            }
        }, lp)

        root.addView(Button(this).apply {
            text = "Undo (purana wapas lao)"
            setOnClickListener {
                if (!hasAccess()) askAccess()
                else runInBackground { "Undo ho gaya: ${undo()} files" }
            }
        }, lp)

        tvLog = TextView(this).apply { text = "Ready" }
        val sv = ScrollView(this)
        sv.addView(tvLog)
        root.addView(sv, lp)

        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            runInBackground { "Done: ${install(uri)} files install hui" }
        }
    }

    // ---------- Permission ----------
    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), reqPerm
            )
        }
        tvLog.text = "Permission allow karke wapas aao, phir button dabao"
    }

    // ---------- Background ----------
    private fun runInBackground(task: () -> String) {
        tvLog.text = "Kaam chal raha hai..."
        Thread {
            val msg = try { task() } catch (e: Exception) { "Error: ${e.message}" }
            runOnUiThread { tvLog.text = msg }
        }.start()
    }

    // ---------- Install ----------
    private fun currentDir(): File = File(prefs.getString("dir", defaultDir)!!)

    private fun safeTarget(base: File, name: String): File {
        val t = File(base, name)
        if (!t.canonicalPath.startsWith(base.canonicalPath + File.separator))
            throw SecurityException("Galat path: $name")
        return t
    }

    private fun writeFile(base: File, name: String, copy: (OutputStream) -> Unit) {
        val target = safeTarget(base, name)
        target.parentFile?.mkdirs()
        if (target.exists()) {
            val b = File(backupDir, name)
            b.parentFile?.mkdirs()
            if (!b.exists()) target.copyTo(b)
        } else {
            installedList.appendText(name + "\n")
        }
        target.outputStream().use { copy(it) }
    }

    private fun install(uri: Uri): Int {
        val base = currentDir()
        base.mkdirs()
        prefs.edit().putString("lastDir", base.absolutePath).apply()

        val cache = File(cacheDir, "mod.tmp")
        contentResolver.openInputStream(uri)!!.use { i ->
            cache.outputStream().use { i.copyTo(it) }
        }
        val head = ByteArray(2)
        cache.inputStream().use { it.read(head) }

        var count = 0
        try {
            if (head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()) {
                ZipInputStream(cache.inputStream()).use { zip ->
                    var e = zip.nextEntry
                    while (e != null) {
                        if (e.isDirectory) safeTarget(base, e.name).mkdirs()
                        else { writeFile(base, e.name) { out -> zip.copyTo(out) }; count++ }
                        e = zip.nextEntry
                    }
                }
            } else if (head[0] == '7'.code.toByte() && head[1] == 'z'.code.toByte()) {
                SevenZFile(cache).use { sz ->
                    var e = sz.nextEntry
                    while (e != null) {
                        if (e.isDirectory) safeTarget(base, e.name).mkdirs()
                        else {
                            writeFile(base, e.name) { out ->
                                val buf = ByteArray(8192)
                                while (true) {
                                    val n = sz.read(buf)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                }
                            }
                            count++
                        }
                        e = sz.nextEntry
                    }
                }
            } else {
                throw Exception("Sirf .zip ya .7z support hai")
            }
        } finally {
            cache.delete()
        }
        return count
    }

    // ---------- Undo ----------
    private fun undo(): Int {
        val base = File(prefs.getString("lastDir", prefs.getString("dir", defaultDir))!!)
        var n = 0
        if (backupDir.exists()) {
            backupDir.walkTopDown().filter { it.isFile }.forEach {
                val rel = it.relativeTo(backupDir).path
                it.copyTo(safeTarget(base, rel), overwrite = true)
                n++
            }
            backupDir.deleteRecursively()
        }
        if (installedList.exists()) {
            installedList.readLines().filter { it.isNotBlank() }.forEach {
                val f = safeTarget(base, it)
                if (f.exists() && f.delete()) n++
            }
            installedList.delete()
        }
        return n
    }
}
